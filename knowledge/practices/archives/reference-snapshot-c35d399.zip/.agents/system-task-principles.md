# System Task Principles

**Purpose:** Durable, additive principles for designing, implementing, and evaluating DevEnv and its domain-modeling and development/meta practices. Application examples illustrate these practices; they do not define the meta concept.

These principles are active from their recorded date and apply to future work in this system. Add later rules as new entries; do not silently replace existing ones. If principles conflict, identify the conflict and ask for a decision before choosing which to follow.

## Principle Register

### P-001 — Red-Green-Refactor

- **Recorded:** 2026-10-05
- **Source:** User instruction; `.agents/skills/tdd/SKILL.md`
- **Applies to:** Production-code changes.
- **Rule:** Follow the TDD sequence: write and run the smallest focused test that fails; write only enough production code to pass it; once green, refactor without changing behavior and keep tests green.
- **Practice:** Do not write production code before a failing test. Treat compile failures as red. For non-code design work, make no claim of TDD execution.
- **Phase reporting (user, 2026-10-09):** When doing TDD, explicitly mention the current state: Red, Green, or Refactor. For example, report Red before running a new failing diagram-document validation test, and Green when implementing its behavior.

### P-002 — Review for Missing or Refinable Types

- **Recorded:** 2026-10-05
- **Source:** User instruction; `.agents/skills/type-detector/SKILL.md`
- **Applies to:** Domain modeling, workflow design, and implementation that changes domain concepts or their representation.
- **Rule:** Regularly inspect the model for concepts that need a Type and existing Types whose boundaries or structure should be refined. Report a justified conviction that a Type is needed to the user; distinguish confirmed Types from candidates and unresolved questions.
- **Sequence:** (1) Derive candidate meanings and constraints from evidence, using a concrete instance and contrasting example where possible. (2) Review candidate names under P-012 and keep unapproved names provisional under P-022. (3) Choose declarations by meaning under P-017, preserving runtime validation. (4) Check for disproportionate existing-Type complexity under P-027 and report candidates rather than refactoring without approval. Revisit the model after considering scope variation and important exceptions, then once before completion. Apply each check when relevant; do not repeat it without new evidence.
- **Review prompts:** Are distinct lifecycle states, outcomes, evidence, decisions, scope levels, roles, or relationships being collapsed into strings or unstructured fields? Does a proposed Type have a distinct meaning, constraints, or lifecycle? Would separating it clarify the model, or merely add ceremony?
- **Complexity signal:** When an existing Type appears to make a scoped behavior unnecessarily complex, report it as a refactoring candidate with concrete alternatives rather than silently working around it; see P-027.

- **Knowledge-transfer modeling pattern (user, 2026-10-07):** Use [Example-Led Knowledge Modeling](../knowledge/practices/example-led-knowledge-modeling.md): meaning, a concrete Markdown example, a candidate Type, JSON, and a check that meaning is preserved. Try a contrasting example before choosing an authoritative representation. Ask for names before adopting them; do not equate a serialization format with the conceptual Type.

### P-003 — Verify Type Safety Before Completion

- **Recorded:** 2026-10-05
- **Source:** User instruction
- **Applies to:** Coding tasks that change TypeScript.
- **Rule:** Before calling a coding task done, run an appropriate TypeScript-aware type-check or build covering the changed code, and resolve the resulting type errors.
- **Practice:** Choose the narrowest repository-supported command that checks the changed project and its relevant consumers. Tests and editor diagnostics alone do not establish type safety. If a check cannot run or has known unrelated failures, report that explicitly and do not claim full type-safety verification.

### P-004 — Domain-Driven Public-Interface Tests at Full Coverage

- **Recorded:** 2026-10-05
- **Source:** User instruction
- **Applies to:** Production modules changed by a coding task.
- **Rule:** Achieve 100% statement, branch, function, and line coverage for those modules. Include another module when it is also changed as part of the task; merely relying on an unchanged module does not expand the coverage scope. Derive tests, wherever possible, from known domain requirements, tasks, and scenarios. Exercise behavior through public interfaces; do not test private implementation details.
- **Test boundaries:** Do not use spies or mock internal collaborators. Simple mocks are permitted only at external/system boundaries. Prefer realistic domain examples and observable outcomes.
- **Production-change restriction:** Do not change production code merely to make tests easier or coverage rise. If code cannot be covered, first demonstrate that it is unreachable and cannot be tested through the public interface; only then may production code be changed to improve or remove the unreachable behavior.
- **Verification:** Run coverage for all four metrics on every production module changed in the task. If 100% cannot be reached, explain the uncovered code and blocker; do not claim the rule is satisfied.

### P-005 — Commit at Stable Checkpoints

- **Recorded:** 2026-10-05
- **Source:** User instruction
- **Applies to:** Coding tasks that reach a validated, stable state.
- **Current rule:** Do not initiate a commit or commit-approval prompt at a stable checkpoint. Commit only after the user explicitly requests it. Keep the commit scoped to the approved work and follow the repository's commit-message conventions.
- **Before committing:** Verify the requested scope. After an explicit commit request, draft a short, subject-only message by default and obtain the user's approval before running the commit. The subject preference is revisable; check P-011 for concern-specific subjects and current attribution preferences.
- **Stable-summary suggestion (user, 2026-10-09):** When work reaches a stable checkpoint and a commit subject can reasonably be proposed, include a suggested subject in the status summary. It is informational only: it neither requests a commit nor constitutes approval. If the user later explicitly requests a commit, verify scope, present the subject for approval, and wait for approval before committing.

- **History:** The original automatic-commit instruction was superseded by the user's 2026-10-07 override. The current rule above preserves the resulting policy without treating the superseded instruction as active.

### P-006 — Ask Before Changing Surrounding Code

- **Recorded:** 2026-10-05
- **Source:** User instruction revising the surrounding-code restriction
- **Applies to:** Changes where existing code outside the immediate feature scope blocks a sound solution, especially styling and layout work.
- **Rule:** Existing surrounding code may be relied upon when reasonably stable, but must not be changed or removed without the user's permission. If a specific, non-generic part of surrounding code is a real blocker, explain the constraint, why a narrowly scoped change is needed, and its likely impact; ask permission before changing it.
- **Boundary:** Do not make broad or application-wide changes on this basis. If the blocker is generic or the impact is uncertain, keep it unchanged and offer a safer scoped alternative or ask for further direction.

### P-007 — Import Jest Globals Explicitly

- **Recorded:** 2026-10-06
- **Source:** User instruction
- **Applies to:** Test files created or modified for this system.
- **Rule:** Verify that every Jest helper a touched test file uses is explicitly imported from `@jest/globals`; put that import on the first line of the file.
- **Practice:** Import only the used helpers (for example, `describe`, `it`, `expect`, `beforeEach`, and `jest`). Do not rely on Jest's ambient globals in touched test files.

### P-008 — Ask Before Continuing Long Tasks

- **Recorded:** 2026-10-06
- **Source:** User instruction
- **Applies to:** Ongoing tasks that take more than three minutes of active task work.
- **Rule:** After each three minutes of active work on the task, pause at the next stable point and ask whether to continue. Do not interrupt a running check or leave the work unstable just to meet the interval.
- **Clock:** Count focused task work; exclude time waiting for the user, a long-running command, or an intentional pause. Reset the interval when the user permits continuation.
- **Loop:** Do not continue until the user explicitly permits it. Before resuming, record any new user-provided rule in this register and relevant project guidance. Stop if the user asks to stop.

### P-009 — Review Domain Wording for Vocabulary and Concerns

- **Recorded:** 2026-10-06
- **Source:** User instruction
- **Applies to:** Reviewing or working from note and Problem descriptions.
- **Rule:** When encountering a concept or wording in a note or Problem description, evaluate whether it warrants a Glossary entry, a new or refined Type, or another general system concern.
- **Practice:** Do not automatically add definitions or Types. Record justified candidates and distinguish them from agreed domain meaning; raise unresolved or consequential interpretations for user review.

### P-010 — Reflect on Meta-Level Knowledge

- **Recorded:** 2026-10-06
- **Source:** User instruction
- **Applies to:** Stable pauses under P-008 and feature-slice completion.
- **Rule:** Briefly check for a concrete, reusable meta-level insight that is not already captured. Record a note only when such an insight exists; do not create a note or extend the task merely to satisfy this check.
- **Practice:** Record the note in `knowledge/domain-models/problem-inquiry-system/concerns.md` under "Meta Notes", numbered `Meta-NNN` in the order added (introduced 2026-10-06, same 3-digit style as `SC-NNN`/`P-NNN`). Notes are observations and proposals, not decisions; raise consequential ones with the user.
- **Meta-meta cadence (recorded 2026-10-06):** After roughly every 10 implemented feature slices (real code and tests; documentation-only or principle-only changes do not count), briefly evaluate whether the accumulated principles and conventions still serve the learning-sandbox purpose, then report the conclusion. Treat the count as approximate; use available history or checkpoints and do not require a session-database counter that may not persist across sessions. This is a periodic review, not an additional checkpoint for every task.

### P-011 — Identify the Referenced Concern in Commit Messages

- **Recorded:** 2026-10-06
- **Source:** User instruction
- **Applies to:** Commit messages for changes that implement, extend, or register a System Concern (SC-NN).
- **Rule:** When a commit's primary subject is one or more SC-NN, start the commit subject with the identifier(s), rendered using the current commit-prefix preference below, followed by a colon and a short phrase describing what this commit contributes. That phrase describes this change, not the concern as a whole: a concern's Title in `concerns.md` is stable across every slice built toward it, while the commit phrase is specific to the current slice and will differ between commits against the same SC-NN.
- **Practice:** Prefer existing, already-understood vocabulary (a commit subject line) over inventing a new proprietary term for this pairing; the "Three ID schemes" meta note already flags the risk of home-grown naming unrelated to external conventions. When a commit touches several concerns, either lead with the most central one or list them (for example "SystemConcern-045, SystemConcern-046: record export and import concerns").
- **User override option:** The user may, at their own discretion and at any time, redefine `NN`, `XX` (the prefix shared by a whole category, for example all of `SC`), or both. The two scopes are written down differently:
  - A word for one concern's `NN` is local to that concern: record it in that concern's own entry in `concerns.md` and use it in that concern's subsequent commit subjects.
  - A word for `XX` renames the whole category, not one entry: reflect it everywhere that prefix's meaning is documented or used as a literal pattern — at minimum the Concern Record format/legend in `concerns.md`, the "Three ID schemes" Meta Note, and this principle itself.
- **Standing default (recorded 2026-10-06):** For now, always use `SystemConcern-NN` (PascalCase, no space or underscore) as the commit-subject prefix in place of `SC-NN`, without asking each time — the user settled on this after trying several styles live (Meta-008, Meta-017). This is still a current preference, not a permanent rule (see "Applying the Register" below); revisit if the user says otherwise.
  Do not pre-assign such words unprompted; this stays an option the user invokes, not a default naming step.
- **Clarification and pre-draft check (user, 2026-10-07; attribution updated by the override below):** Preserve the register's three-digit number in commit subjects, for example `SC-044` becomes `SystemConcern-044:`. Before drafting any commit message for approval, read P-005 and this principle, then check the current naming preference, the scope-specific subject, and the current attribution preference. Approval follows validation and does not replace it. Keep the short project guidance consistent with this preference. Automated enforcement is not authorized by this decision.
- **Co-author attribution override (user, 2026-10-07):** Omit the Copilot `Co-authored-by` trailer from commits until the user says otherwise. This is a standing waiver of the earlier trailer requirement, including when the assistant edits code or documentation; it is not limited to commit-message assistance. Commit initiation and message approval rules remain unchanged. The pre-draft check must use this current attribution preference rather than adding the earlier trailer.

### P-012 — Review Naming Decisions From Either Direction

- **Recorded:** 2026-10-06; merged with the former P-013 on 2026-10-06 after the user flagged the two as one topic split across separate entries.
- **Source:** User instruction
- **Applies to:** Moments where a name for a new Type, Term, or other mapping/identifier is being considered or proposed, whichever side raises it.
- **Rule:** When a candidate name surfaces — whether I consider it mid-reasoning (per P-002/P-009) or the user proposes it directly — do not silently accept it or only record it in the artifact. Check it against existing names in `.glossary`, the shared Types, and the principle register for consistency (style, collisions with an existing meaning), then either ask the user for their view (if I raised the candidate) or report my honest assessment (if they raised it) before it is adopted.
- **Practice:** Keep this to genuine candidate Type/Term *names*, not every passing word already noted in the register. Use the `ask_user` tool when I raise a candidate; report findings plainly when the user raises one. Final agreement on any name still rests with the user; this is a check-and-surface step, not a veto.

- **Adoption threshold (user, 2026-10-09):** Treat every new or candidate name/Term as provisional, including one proposed by the user, until the user explicitly states that it is adopted or approved. A proposal, example, or use of a name is not by itself approval. Existing names already explicitly established remain established.
- **Definition and reference policy (user, 2026-10-07):** Glossary entries explain Terms; instructions for how we refer to them belong in working guidance, not their definitions. When referring to our current SubjectDomain, write `SubjectDomain (WMS)` to make the concrete subject explicit. This qualifies the reference, not the abstract Term's meaning.
- **Concrete reference rule (user, 2026-10-07):** For concepts we introduce, including process names and Terms, accompany the abstract name with a named concrete instance from the actual system or meta practice, for example `SubjectDomain (WMS)` or `KnowledgeStatement (commit-attribution)`. This improves reader understanding without equating the concept with that instance. Use a genuine instance, not an invented mapping; if none is known, make that gap explicit. Keep abstract Glossary definitions separate from this reference policy.
- **Example selection preference (user, 2026-10-07):** Prefer Term examples from SubjectDomain (WMS), DevEnv, or our meta practices. Choose a clear, genuine example; do not force a fit or invent domain facts. These are preferred example contexts, not a decision that each is a separate formal Domain.
- **SubjectDomain name override (user, 2026-10-07):** Rename the Glossary entry to `SubjectDomain (WMS AI)`, including the example in the Term name while retaining its abstract definition. The user shortened the initial wording "AI for WMS" to "WMS AI". Use this name for that example instead of the earlier `SubjectDomain (WMS)` reference preference. Historical WMS references retain their context; this rename does not assign defining Domains or change export scope.

### P-013 — *(retired, merged into P-012)*

- **Recorded:** 2026-10-06; retired 2026-10-06. Originally "Verify User-Suggested Names for Consistency and Sense" — the user pointed out, while asking for an honest evaluation of the pace of recent principle additions, that this was the same topic as P-012 split across two entries. Merged into P-012 rather than deleted, so the record of the change stays visible.

### P-014 — Keep Tests Free of External I/O

- **Recorded:** 2026-10-06
- **Source:** User instruction; SC-053
- **Applies to:** Test setup, cleanup, and application/subprocess behavior exercised by tests.
- **Rule:** Test scenarios and application/subprocess behavior invoked by tests must not perform external I/O or mutate the real filesystem. Read-only filesystem access is allowed. Use simple Boundary Mocks at external-I/O boundaries while retaining actual application/domain behavior under test.
- **Infrastructure exception (user, 2026-10-06; reaffirmed 2026-10-09):** Runner-generated coverage reports and caches are allowed; see "Allowed exceptions."
- **Migration:** Existing suites that perform mutations are tracked in SC-053. Migrate them in bounded slices without silently dropping persistence or Git behavior coverage.
- **External-I/O boundary (user, 2026-10-09):** Prohibited test I/O includes real network activity; localhost servers, socket listeners, and loopback requests are not exempt. This applies to setup, cleanup, and application/subprocess behavior invoked by tests.
- **Allowed exceptions:** Console logging is allowed. Test-runner coverage output and caches are explicitly allowed infrastructure artifacts; these do not authorize filesystem writes or network activity by test scenarios or invoked application code. Isolated test-local memory and DOM changes are not external I/O.
- **Concrete example:** The DevEnv backend service, file browser, and file editor client tests now use `HttpTestingController` instead of starting Express and accessing real fixture files. Existing server tests using Supertest or TCP listeners still require migration under this broader rule; passing coverage does not establish side-effect compliance.
- **Logging candidate:** The existing client `LoggerService` provides a console-error boundary that tests can capture with a simple Boundary Mock. A dedicated test logger is suggested, not adopted; do not add another abstraction or treat the client Angular service as an agreed server logger.

### P-015 — Maintain Structured Data in JSON and Generate Markdown Views

- **Recorded:** 2026-10-07
- **Source:** User instruction
- **Applies to:** Structured data storage and transfer in this system, unless the user specifies otherwise.
- **Rule:** Use JSON as the source of truth for structured data. Generate Markdown views from that JSON rather than maintaining Markdown as a second authoritative copy.
- **Practice:** Keep the generated view reproducible from its JSON source, identify it as generated, and do not let application behavior depend on parsing the view when the structured JSON is available.

- **Format preference refinement (user, 2026-10-07):** Prefer structured formats over unstructured representations for data storage. The default order is **Typed JSON, then YAML, then Markdown**. Typed JSON means JSON with an explicit interface describing its structure; JSON alone is not typed, and an interface alone does not validate runtime input. Prefer generating `.md` views from the authoritative structured source rather than extracting the authoritative data from Markdown. Include this preference in the portable practices package, not only local project policy. Preserve meaning when choosing a format and record justified exceptions or explicit user choices. This does not authorize automatic migration of existing Markdown sources.

### P-016 — Verify Practices and Report Deviations

- **Recorded:** 2026-10-08
- **Source:** User instruction
- **Applies to:** Requested work, user proposals/actions encountered during that work, and the assistant's own approach.
- **Rule:** Use confirmed, applicable good practices rather than unverified assumptions. Check existing project processes first and consult maintained guidance, official documentation, or credible evidence where needed. Do not claim a preference or plausible recommendation is a confirmed standard.
- **Reporting:** When an approach conflicts with good practice or differs from an existing process, provide a concise report in the conversation: observation, applicable process or practice with evidence, likely impact, and recommended alternative. Distinguish a harmful practice from a legitimate variation; make uncertainty explicit. A separate persisted report is not required unless requested or needed by the existing workflow.
- **Decision boundary:** Raise consequential conflicts before implementing them and seek a decision where needed. Do not silently override project policy, automatically adopt an external recommendation, or expand the task into unrelated cleanup. P-029 permits narrow, reversible, low-impact process improvements when concrete evidence supports them; consequential, hard-to-reverse, or materially uncertain changes still require a decision. Record intentional deviations in the appropriate existing checkpoint.
- **Actual instance:** DevEnv skills were initially stored in root `skills`, which is not a standard Copilot discovery location. The corrected project location is `.agents/skills`; file placement follows documented discovery conventions, while discovery on a receiving client still requires verification.
- **Optional method prompt (user, 2026-10-08):** When a decision compares competing optional work candidates, assess whether RICE is appropriate and ask whether to apply it before scoring. Use the [RICE prioritization guidance](../reviews/rice-prioritization.md): comparable contexts, explicit estimates and evidence, and separate decision rationale. Missing evidence is a reason to gather estimates or recommend a simpler comparison, not invent scores. Do not ask routinely for single already-selected tasks, use RICE to rank binding rules, or let it override dependencies and mandatory constraints.
- **Prioritization example:** The pending Principle Register Organization and Priority Review and Term Editing workflows are actual optional work candidates. RICE could inform their execution order only if a common goal/context and defensible estimates can be established; it would not establish precedence among the P-NNN rules themselves.

### P-017 — Choose TypeScript Declarations by Meaning

- **Recorded:** 2026-10-09
- **Source:** User instruction: "The useful distinction is a named value/choice versus properties grouped into a record."
- **Applies to:** New or substantively revised TypeScript declarations in DevEnv.
- **Rule:** Use `type` for a named value or choice; use `interface` for properties grouped into a record. This distinguishes declaration forms, not single versus multiple instances or the importance of a domain Type.
- **Explicit union alternatives (user refinement, 2026-10-09):** Define each structured union alternative as a named interface, then combine those interfaces with a `type` union. Prefer explicit record interfaces over inline anonymous records even when the alternatives are not independently reused. Review new variant names under P-012 before adopting them.
- **Language boundary:** Unions of records and derived types require a `type` alias. Preserve variant-specific discriminants and their associated required properties; do not flatten a union into an interface with optional fields merely to follow the convention.
- **Examples:** In the [diagram editor plan](../knowledge/workflows/diagram-editor-workflow.md#minimal-model), `DiagramPoint` is an interface grouping `x` and `y`; `DiagramElementKind = DiagramElement['kind']` is a derived named choice; `DiagramElement` is a union of valid record alternatives. The current sketch uses inline alternatives; bring those into named interfaces when revising that model, after agreeing their names. These are planned declarations, not implemented instances. The user's `type FormID = string` illustrates a named value but is not an established DevEnv Type.
- **Limits:** A string alias does not create a nominally distinct ID or validate input. Neither declaration form replaces runtime validation. Interfaces support declaration merging; choosing one here does not authorize or require merging.
- **Scope:** Apply the convention going forward and within agreed changes; do not refactor existing declarations solely for consistency.
- **Evidence:** The [TypeScript handbook](https://www.typescriptlang.org/docs/handbook/2/everyday-types.html#differences-between-type-aliases-and-interfaces) explains that object-shaped aliases and interfaces overlap and often permit a preference. This rule is the project's readability convention, not a universal TypeScript requirement.

### P-018 — Split Functions at Functional Boundaries

- **Recorded:** 2026-10-09
- **Source:** User instruction to keep functions short and split them at functional boundaries.
- **Applies to:** New code and explicitly requested refactoring.
- **Rule:** Prefer short, cohesive functions. Extract distinct responsibilities that make sense on their own; do not impose an arbitrary line limit or add trivial forwarding helpers merely to shorten a function.
- **Concrete instance:** Diagram document validation orchestrates document-level checks, element validation, and connection collection validation. Connection collection validation owns duplicate IDs and undirected pairs; element validation owns kind-specific records and position checks.
- **Verification:** Refactor from a green baseline, preserving observable behavior, validation order, explicit errors, type safety, and full in-scope coverage through the public interface.
- **Scope:** This preference does not authorize unrelated refactors or new domain Types.

### P-019 — Keep Shared Code Valid in Both Runtime Contexts

- **Recorded:** 2026-10-09
- **Source:** User instruction that `@shared` should contain only code valid for both client and server.
- **Rule:** Shared contracts and executable code must be valid in both the browser client and Node server. Apply this requirement to transitive dependencies and the public export/package surface, not merely a function's implementation.
- **Boundary:** Keep browser-only APIs, Node-only modules, Angular-specific integrations, and runtime-specific adapters in their respective projects. Shared logic may express runtime-neutral contracts; implementations at external boundaries remain context-specific.
- **Concrete instance:** Diagram document Types and validation use standard JavaScript without browser or Node dependencies. The existing shared Angular component and service are migration debt under this rule, not evidence that the current package is fully runtime-neutral.
- **Verification and scope:** Verify executable shared additions in both contexts when claiming cross-runtime compatibility. Preserve existing consumers until a migration is explicitly scoped; this note does not authorize relocating exports, changing packaging, or introducing a shared logger.
- **Authorized cleanup (user, 2026-10-09):** Removed unused shared Angular component/service scaffolding, their exports/tests, and Angular runtime peers. Retained the existing package build tooling. The Node public-API regression and native Node execution of the built package validate diagram-document execution without Angular; shared/client builds and both test type-checks pass. No runtime-specific consumer required relocation.

### P-020 — Review Duplication After Green

- **Recorded:** 2026-10-09
- **Source:** User instruction to review duplication during TDD's Green stage and extract reusable functions where appropriate.
- **Applies to:** Production-code TDD slices.
- **Rule:** After the focused test is Green, inspect the changed code for duplicated behavior and consider whether it can be extracted at a cohesive functional boundary that can be reused. Extract when it clarifies a responsibility or gives meaningful reuse; do not abstract coincidental similarity, trivial expressions, or code without a clear caller.
- **Sequence:** Keep Red focused on one behavior; implement only what makes that test pass; review duplication at Green; then validate the Refactor without behavior change, maintaining type safety and full in-scope coverage.
- **Scope:** This is a review obligation, not a requirement to extract code whenever lines look alike, and it does not authorize unrelated refactoring.

### P-021 — Report Stability When Stopping

- **Recorded:** 2026-10-09
- **Source:** User instruction: "when you stop doing things (either when done, or pausing or asking commit) show me if we are stable or not (meaning 100 and running code)"
- **Applies to:** Responses that end a task, pause ongoing work, or request commit-message approval.
- **Rule:** At each applicable stopping point, include a clearly labeled `Status: Stable` or `Status: Not stable` line. `Stable` means all applicable tests, four-metric coverage for changed production modules, and required type-check/build pass. Run an actual UI/runtime check when the acceptance condition depends on runtime behavior; otherwise state separately when it was not performed. If an applicable check fails or remains pending, report `Not stable` and name the gap. For documentation-only changes, say they are documentation-only and report the relevant diff/format check instead of implying code checks ran.

### P-022 — Keep Unagreed Names Provisional

- **Recorded:** 2026-10-09
- **Source:** User instruction to treat all names and Terms as provisional until explicitly stated.
- **Applies to:** New or candidate names for Types, Terms, mappings, and other meaningful concepts, in discussion and artifacts.
- **Rule:** Treat every new or candidate name as provisional until the user explicitly states that it is adopted or approved, whether the candidate came from the user or the assistant. A proposal, example, or use of a name is not by itself approval. If an interim name is needed, mark it as provisional and do not present it as established; apply P-012 before adoption. Existing names already explicitly established remain established.
- **Practice:** Keep an explicitly approved name distinct from provisional supporting names. For example, `WorkEvaluation` is approved for a unit-of-work evaluation; `EvaluationMetric` and `WorkEvaluationDataset` in the DevEnv value-evaluation JSON remain provisional.

### P-023 — Include the Global TODO and Metrics in Status Reports

- **Recorded:** 2026-10-09
- **Source:** User instruction: "when showing the status, also show me a report of the global todo list with its status and metrics."
- **Applies to:** Responses that present a `Status:` line.
- **Rule:** Alongside the stability status, report every workflow in the global Workflow TODO List with its current registered status, and summarize the available value-evaluation metrics from their authoritative source.
- **Default format:** List every workflow name and status compactly, grouped by status where practical; include counts. Summarize the metric sample size, recorded-versus-unknown coverage, and material limitations without repeating every evaluation field. Expand to per-evaluation detail when requested or needed to explain a decision.
- **Ordering (user, 2026-10-09):** Separate the concluding lines from the preceding report with one blank line. End with the `Status:` line; if a proposed commit message is relevant, put it immediately after the status line as the final line of the report.
- **Interpretation:** Connect an evaluation to a workflow only when the source explicitly supports that link. Keep workflow lifecycle status separate from measured outcomes: completion, activity, tests, or coverage alone do not prove value. Preserve unknowns as unknown and identify the source.

### P-024 — Treat View Changes as Presentation-Only by Default

- **Recorded:** 2026-10-09
- **Source:** User instruction: "in general when i say change view i mean the presentation only not the underlying type"
- **Applies to:** Requests to change a view or how information is presented.
- **Rule:** Interpret a view change as presentation-only by default. Do not change underlying domain/shared/API Types or authoritative data unless the user separately requests that change.
- **Practice:** For example, removing the resume-reference column from the Workflow TODO view does not remove `resumeLabel` or `resumePath` from the `WorkflowTodoList` API Type or authoritative JSON.

### P-025 — Use Concise Transformed Test Data

- **Recorded:** 2026-10-09
- **Source:** User instruction
- **Applies to:** Sample data and fixtures in tests.
- **Rule:** Do not use live application or domain records directly as test samples. Create a concise, clearly named transformation of representative data that preserves only the distinctions and constraints required by the test. Omit unrelated fields and details so readers can quickly understand what the example proves.
- **Practice:** Prefer synthetic, readable values and state when a fixture is illustrative. For example, practice-set history tests use a short generic two-version fixture with synthetic commits and dates rather than copying the live DevEnv registry. Preserve relevant invariants; simplification must not make the example invalid or success-shaped.

### P-026 — Ask How to Track New Tasks

- **Recorded:** 2026-10-09
- **Source:** User instruction: ask whether to add a TODO and keep metrics when starting a new task.
- **Applies to:** A new, substantive user-requested task, before implementation begins.
- **Rule:** Ask separately whether the user wants the task registered in the Workflow TODO List as resumable work and whether an eligible coding slice should receive a WorkEvaluation record. Wait for the user's choices before implementation; do not assume either choice from the other.
- **Practice:** Explain that a Workflow TODO entry is for work the user wants to track as resumable, while a WorkEvaluation records the agreed outcome and measures for an eligible coding slice. If the task is not eligible for evaluation, say so. Do not repeat the prompt when continuing an already-started task or answering a follow-up within it.

### P-027 — Report Disproportionate Type Complexity

- **Recorded:** 2026-10-09
- **Source:** User instruction: when an existing Type makes a solution more complicated than necessary, report it for refactoring with suggestions.
- **Applies to:** Type review during implementation, modeling, or maintenance.
- **Rule:** When evidence shows that an existing Type adds disproportionate complexity to the required behavior or obstructs a scoped solution that could be expressed more simply without losing meaningful constraints, report it to the user as a refactoring candidate and offer concrete alternatives.
- **Practice:** Identify the Type and its callers, explain which complexity is unnecessary for the current goals, compare a simpler representation against meaningful invariants and other consumers, and state likely tradeoffs. Distinguish confirmed waste from an unresolved candidate. Do not silently work around the Type, rename or weaken it, or perform the refactor without agreement; retain it when its constraints protect other known behavior.
- **Concrete contrast:** `DiagramConnection` captures persistent endpoints and a label with document-level non-self and duplicate-pair invariants; its structural detail enables validation and should not be called needless merely because a UI needs transient connect mode. The selected `readFileSync` in the evaluation test reads authoritative JSON and is not a Type-complexity instance.

### P-028 — Prefer the Smallest Useful Initial Slice

- **Recorded:** 2026-10-09
- **Source:** User instruction: "dont go overboard adding every feature and option available a simple start is good for now"
- **Applies to:** Scope selection for design and implementation.
- **Rule:** Prefer the smallest useful slice that fulfills the agreed outcome over implementing every available model, provider, or option. Defer optional expansion unless the user agrees, while keeping the required behavior accurate and explicit.
- **Practice:** State the initial slice and leave optional capabilities as future work rather than silently expanding scope. A task-specific instruction remains scoped to that task unless the user says it is general or concrete evidence supports generalizing it under P-029; report any generalization. For example, the Copilot AI Credit Estimator began with one normalized JSON paste-and-estimate flow; that instance alone would not establish a universal scope policy.

### P-029 — Apply and Report Evidence-Based Process Improvements

- **Recorded:** 2026-10-09
- **Source:** User instruction: "if you think the changes are beneficiary and have evidence, you can make the change without asking, but always report it"
- **Applies to:** Proposed improvements to project principles, processes, and related working guidance.
- **Rule:** Make a process improvement without prior approval only when concrete evidence supports its benefit and the change is narrow, reversible, and low-impact. Always report the change, its evidence, and its expected impact.
- **Decision boundary:** Ask before making consequential, hard-to-reverse, or materially uncertain process changes, consistent with P-016.
- **Practice:** Evidence may include an observed recurring friction or a verified practice applicable to this project; plausibility alone is insufficient. Distinguish evidence from judgment, state material uncertainty or tradeoffs, and keep the change scoped to the demonstrated improvement. A task-specific user instruction is not automatically a standing rule; generalize it only when the user says it is general or concrete evidence justifies the broader benefit, and report that generalization.

### P-030 — Find Functional Boundaries Before Test Spies

- **Recorded:** 2026-10-09
- **Source:** User instruction: when tests need spyOn calls, find the functional boundary and make or propose an interface and mock for it.
- **Applies to:** Writing or changing tests that would use spies, global patches, or similar test-framework interception, including fake timers.
- **Rule:** Before adding interception, trace the consumer's interaction to its functional boundary. Reuse an appropriate existing interface or implement or propose a small consumer-derived role interface with a plain mock/fake, and inject that boundary into consumer tests. Follow existing Type/name approval and surrounding-code scope rules when introducing the interface; do not silently adopt speculative names or expand the task.
- **Practice:** Derive operations and lifecycle obligations from actual use, not the supplier's entire API. Verify observable results, required arguments, errors, and cleanup through public interfaces. Do not introduce interfaces for internal implementation details merely to enable mocking. Necessary spies or fake time may remain in real boundary-adapter tests; explain why they are needed rather than treating all framework interception as forbidden.
- **Concrete instances:** InteractiveCanvas uses IBrowser with a plain MockBrowser; its adapter tests patch actual browser APIs. The status toolbar uses IScheduler with a plain MockScheduler to deliver recurring refresh ticks; only the real scheduler adapter tests use Jest fake timers. A current-time reader would have a different role from this recurring scheduler; an IClock remains a candidate rather than an adopted abstraction.
- **Benefit and boundary:** Explicit collaboration replaces global test patching in consumers and makes cancellation and other boundary obligations reviewable. An interface alone does not guarantee those obligations or justify migrating unrelated tests. This extends P-002/P-004/P-014 without authorizing internal collaborator mocks or external I/O.
- **Clarification (user, 2026-10-09):** Jest spies and similar helpers are explicitly allowed in tests of the boundary adapter or mock/fake itself. This permission is not limited to real adapter tests; for example, a test of MockScheduler may use a Jest callback spy to verify tick delivery. Consumer tests should still use the injected boundary contract rather than patching globals or internal collaborators.
- **Pre-test dependency check (user, 2026-10-09):** Before writing or changing tests, identify external dependencies and search for existing contracts and mocks/fakes, including nearby tests. If a suitable mock exists, use it through its boundary contract rather than bypassing it with direct external calls or Jest interception. If none fits, identify a good consumer-derived boundary and propose an interface with a plain mock/fake, obtaining required Type/name and scope approval before implementing it. If Jest interception such as `spyOn` or fake timers is necessary instead, explain the concrete reason before using it; state why an existing or proposed boundary does not fit. Adapter/mock-test permission above remains valid, but is not a blanket justification for interception in consumers.
- **Correction example:** CanvasDiagramEditor initially kept direct `setInterval` and timer-advancing tests despite the existing IScheduler/SCHEDULER and toolbar MockScheduler pattern. Reusing that contract with a plain MockScheduler verifies one-second redraw requests and cancellation without fake timers. Current-time reading is a separate dependency and does not justify bypassing the recurring scheduler.
- **Execution checkpoint (user-approved, 2026-10-09):** Place the dependency/mock check before test writing in the [focused work loop](../AGENTS.md#focused-work-loop), and review practice compliance separately from behavior, coverage, and build results before completion. Preserving scope is not permission to silently waive this check; raise conflicts before acting under P-016. The [three-slice checklist trial](../AGENTS.md#checklist-trial) records misses, corrections, and friction in existing workflow checkpoints to evaluate whether this execution change helps. Keep the register's rationale and history; no new principle or automated enforcement is introduced.

### P-031 — Synchronize the Recorded TDD Phase

- **Recorded:** 2026-10-09
- **Source:** User request after the toolbar remained NOT SET while TDD phases were reported only in chat.
- **Applies to:** Agent-led production work using Red-Green-Refactor in this repository.
- **Rule:** Before entering each phase, replace the repository-root `.rgr-phase` contents with its lowercase value (`red`, `green`, or `refactor`) and explicitly report that phase in chat. Verify the saved value. A chat announcement alone does not update the application.
- **Lifecycle:** Empty the file when pausing, completing, or switching away from TDD work. On resuming, record the actual phase; do not invent a phase for documentation-only work or backfill historical transitions. A failed test remains Red until implementation begins; passing tests do not justify recording Refactor unless that phase is actually entered.
- **Verification and errors:** The existing GET `/rgr-phase` endpoint reads the last non-empty line; an empty or missing file yields no recorded phase. When the API is running, verify its response after updating state. The toolbar polls every 30 seconds, so distinguish verified saved/API state from an immediately updated visible label. Report write/read failures rather than silently claiming the state is synchronized.
- **Shared-work boundary:** This file is repository-wide, not session-specific. If another worker is using the same phase state, surface the conflict and coordinate ownership rather than overwriting their work. These writes are operational agent actions, never test-scenario filesystem mutations; P-014 still applies.
- **Concrete instance:** During the toolbar scheduling refinement, Red/Green/Refactor announcements were made in chat while the API returned null and the toolbar correctly displayed NOT SET. This rule closes that reporting gap without changing the phase API or adding automatic enforcement.

## Applying the Register

Keep work traceable from its question or requirement and evidence through findings, decisions, and outcomes. Principles guide how work is performed; they do not by themselves establish domain facts or authorize unreviewed production changes.

Stylistic and naming choices the user makes within these principles (for example a commit-message length, a word for `XX`/`NN` per P-011, or a candidate Term per P-012) are current preferences, not permanent commitments. Treat them as part of an ongoing experiment: it is fine, and expected, for the user to revisit any of them later without needing special justification, and a past choice does not bind a future one.
