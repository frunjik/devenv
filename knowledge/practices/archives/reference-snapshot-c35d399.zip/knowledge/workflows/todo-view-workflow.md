# TODO View (DevEnv system layer)

**Registered:** 2026-10-07. Read-only UI implemented and validated; user acceptance remains separate.

## Scope

Create a view of the repository's [Workflow TODO List](./workflow-todo-list.md) in DevEnv's system layer. Displaying workflows is requested; editing, switching workflows through the UI, and persistence changes remain undecided.

## Steps

1. Inspect existing system-layer navigation and document-loading patterns. Agree placement, displayed information, and read-only versus interactive scope.
2. Agree the source of truth and loading contract. Avoid a second hand-maintained workflow list; determine how checkpoint links can be opened from the application.
3. Review necessary Types and names with concrete examples. Identify any related SystemConcern before implementation; none is assigned by this registration.
4. Implement the agreed scope using Red-Green-Refactor and existing client/server patterns. Surface loading failures explicitly.
5. Validate with relevant tests, 100% coverage on all four metrics for in-scope production code, appropriate TypeScript checks/builds, and browser checks for navigation, accessibility, and responsive layout.
6. Update related documentation and save the result and remaining questions. User acceptance and commits remain separate decisions.

## Checkpoint

### Main process navigation and Tools dropdown

- Same-task wording refinement: rename Tools items Server and Client to Edit Server and Edit Client. Routes, query parameters and actions unchanged.
- Same-task styling refinement: right-align Tools with an automatic inline-start margin, preserving final DOM order and Material dropdown behavior. Browser measures zero gap to navigation right edge at 1280/768/320px; dropdown remains within viewport and no document overflow. Fresh client build, diagnostics and diff check pass. Append follow-up quality evidence to the opted-in evaluation without altering original completion/elapsed timestamps; follow-up effort unmeasured.
- Tracking in TODO View and WorkEvaluation explicitly approved. Keep System plan, Workflow TODO, Evaluations, Terms, Glossary, Diagram and Canvas visible. User approved Tools as the final dropdown label; all other existing toolbar routes/actions move into it.
- Preserve routes, query parameters, clone/commit events and disabled committing state. Use Angular Material menu for focus, keyboard and overlay lifecycle rather than another custom boolean. No new domain Type warranted for a fixed presentation grouping.
- Baseline recorded in toolbar-process-links-and-tools-menu before implementation. Next: failing grouping/menu tests, minimal implementation, coverage/build and desktop/narrow keyboard checks.
- Red observed against old grouping and missing dropdown. Green: four focused navigation tests pass with 100% statement/branch/function/line component coverage; existing route parameters, clone/commit events and disabled state verified. Material menu replaces the custom expansion boolean. Paused at continuation gate; phase cleared. Next: formatting cleanup, client/test-source type checks, browser keyboard/responsive checks and completion metrics.
- User approved continuation. Refactor tidied markup and removed obsolete expansion CSS; final four tests retain 100% all-four coverage, test-source type-check and client build pass. Browser at 1280/768/320px verifies all nine Tools items, Enter opening, initial/ArrowDown focus, Escape closing and trigger focus restoration with no page overflow. Original browser share expired; verification used a new running-page tab. Diagnostics/diff check pass.
- WorkEvaluation completed at 01:30:37.535+02:00: 3m 13.425s wall-clock including approvals, not effort. Decision latency, active effort, waiting duration, overhead and user impact remain unknown. Phase cleared; no new domain Types or remaining refactoring justified. Changes uncommitted; next user review or requested commit.

### Toolbar global-grid alignment

- User opted into a separate refinement WorkEvaluation linked to TODO View. Record toolbar-status-order-and-workflow-alignment retrospectively; preserve the completed toolbar-global-grid-alignment record. Known request/build timestamps give 1m 27.843s wall-clock, not effort. Decision latency, active effort and process overhead remain unknown.
- Refinement verification: right justification confirmed in browser; TDD DOM-order test observed failing before the move, then all 6 toolbar tests and client build passed. Browser confirms TDD before Tests on the same row at 1280/768/320px without page overflow; diagnostics/diff check pass. Subsequent commit preflight confirms 100% statement, branch, function and line coverage for StatusToolbarComponent. Changes uncommitted; user usefulness and follow-up defects unknown.
- Same-task refinement: move TDD phase before test status in DOM and responsive grid order; preserve phase labels, colors, tooltips and active-workflow action.
- Same-task user refinement: right-align active-workflow button content within its allocated footer region using flex justification. Keep the existing narrow stacked arrangement, action, hover and focus behavior.
- Same-task follow-up: user approved transparent active-workflow refresh control and requested review of further improvements. Remove resting background/visible border, retain border geometry, subtle hover surface and existing focus outline. Action and dimensions unchanged; no new tracking/metrics opt-in required. Additional recommendations remain review-only.
- Verified transparent resting surface/border, 8% hover surface after transition and 2px keyboard focus outline on running page; final client build/diagnostics/diff check pass. Desktop/narrow screenshots suggest further review-only candidates: mobile workflow-name truncation, secondary navigation dominating the wide toolbar, and Refresh sitting beside the name rather than at the allocated region's right edge. Existing alignment, palette and native controls retained; no new Type warranted.
- Tracking and WorkEvaluation separately opted in. Align outer toolbar content to the framed page boundary with a shared shell-inset token. Top brand occupies four guides; navigation starts at column 5. Bottom current-workflow group occupies the final eight guides. Preserve existing actions, fixed footer reservation and mobile wrapping. Style-only: no TDD phase or new Types required.
- Baseline recorded in toolbar-global-grid-alignment; outcome and effort initially unknown. Next: measured wide/narrow alignment, relevant toolbar tests and client build.
- Completion: 12 navigation/status tests and final client build pass. Browser confirms exact page/top/bottom edges at 1280/768/320, wide column-5 starts within .04px and no narrow document overflow. At medium width controls pushed beyond their guide; user approved stacked footer below 60rem and matching shell 132px clearance. Measured stacked height 97.78px fits reserved space. Shared shell inset matches existing frame, no runtime/Type changes. Evaluation completed; latency/effort/overhead remain unknown. Uncommitted.

### Workflow TODO grid alignment

- User requested better use of global grid guides in Workflow TODO. Semantic table columns now span 4/2/2/4 guides, with shared gutters reserved on each non-final cell. Subtotal text aligns to columns 1/5/9; separators sit in gutters instead of indenting labels. Active-workflow heading shares the page edge, and active-row accent sits below the name without shifting content. Section spacing reuses the shared token.
- Browser exposed native table mixed percentage/length column sizing resolving to equal widths. Use inline-size container-relative lengths for the table, preserving its 42rem narrow-screen minimum and contained horizontal scrolling.
- Style-only change; no domain, Type, API or interaction changes. All 23 component tests pass; final client build, diagnostics and diff formatting pass. Measured table starts match global guides within .03px at 1280px and exactly at 768px; totals align to those guides. At 320px totals stack, table scrolls locally and document width is 305px. Changes uncommitted.

### Editorial layout pilot

- User approved a first slice covering Workflow TODO, Workflow evaluations and inner navigation only. Other routed pages and outer meta toolbars remain unchanged; active workflow selection stays canvas.
- Shared CSS layout contract in client styles: responsive outer margin, gutter, small/section spacing and 12 equal column guides; one column at 42rem and below. Opt-in layout-page owns page padding. Inner navigation consumes the same margin token within the existing shell frame.
- TODO totals span four columns each; evaluation Title/Status/Duration span 7/2/3 columns. Expanded left fields follow Title (including its disclosure indentation), right fields follow Status and span the remaining five columns. Native disclosures, semantic evidence tables, bounded prose and contained table scrolling remain intact. Six-column intermediate layout, subgrid inheritance and migration of other pages are deferred, not claimed complete.
- Two page-layout opt-in tests failed before implementation. Final 30 page tests pass with 100% line/statement/branch/function coverage for both page components; full test-source type-check, client build, diagnostics and diff formatting pass. AppComponent suite also attempted: failures report outstanding GET workflow-todo requests in existing test cleanup; no shell behavior or HTTP changes made and the suite remains an encountered validation limitation.
- Browser measurements at 1280/768/320 confirm shared navigation/page content edges, equally sized TODO totals on wide layouts, stacked narrow layout and no document overflow. Grid spans preserve expanded-field alignment with header content. No new domain Types justified: these are presentation rules over existing WorkflowTodoList and WorkEvaluation values.
- Stable first slice is uncommitted. Next: user visual review, then decide whether intermediate reflow or a grid-guide overlay is useful before migrating additional routes. Do not expand scope automatically.

### Expanded evaluation hierarchy

- User refinement: expanded context and timing reuse the header grid. Left fields align with Title; right fields start at Status and span the remaining width. Evidence aligns with Title; narrow layout still stacks without overflow.
- User follow-up: Measures and evidence is a nested native disclosure, collapsed by default. Existing measures table remains inside; scope outer summary grid/indicator to direct children so nested summaries retain their native marker. Observed nested-disclosure Red before implementation; no domain/Type changes.
- Nested disclosure verified: seven tests, 100% all-four component coverage, test-source type-check, client build and diagnostics pass. Browser Enter expands/collapses evidence independently; parent remains open and nested summary retains list-item display. No remaining cleanup; changes uncommitted.
- User requested larger labels with explanatory values beneath in expanded evaluations. Screenshot shows dense inline label/value paragraphs and long lines. Use semantic definition lists, larger context labels, bounded text measure and responsive two-column grouping. Timestamps are a quieter separated group; measures/evidence has a clear heading. Preserve compact summary rows, palette, all data and disclosure behavior.
- Initial labelled-field test failed before implementation, but its empty metric/measure lists were invalid under the dataset validator, so this was not a sound behavior-specific Red. Corrected the boundary fixture to include a valid metric and corresponding measure before final verification. Reuse WorkEvaluation fields unchanged; no new Type, domain meaning or explanatory claims added.
- Verified seven tests with 100% all-four component coverage, test-source type-check, client build and diagnostics. Running-page checks confirm 18px labels above values, two context columns at 1280px and one at 320px, 305px document width at 320px and keyboard expansion. No further Type cleanup or refactoring; changes uncommitted.

### Table-like evaluation rows

- User chose table-like native expandable rows rather than a semantic table rewrite: shared Title/Status/Duration header, no card outlines, tighter spacing and horizontal separators. Keep native disclosure semantics and evidence. Hide the desktop column header when fields stack on narrow screens.
- Observed missing-column-header Red before implementation. Presentation-only change reuses the existing dataset and formatter; no new Type or lifecycle warranted.
- Verified six tests with 100% all-four component coverage, full test-source type-check, client build and diagnostics. Scoped duration assertions to evaluation rows after the shared header exposed an overly broad selector. Browser confirms matching header/row column positions, bottom-only 1px borders, zero corner radius, Enter expansion/collapse and 305px document width at 320px. No further refactoring needed; uncommitted.

### Padded elapsed units

- User chose padding displayed units only: 02m 08s and 01h 02m 08s, still omitting zero hours. Shared formatter applies consistently to evaluation headers and Workflow TODO histories/totals. Unknown/unavailable and incomplete semantics unchanged; hours above 99 retain all digits.
- Observed seven formatting failures before implementation, including zero duration, summed milliseconds and long durations. Existing elapsed value representation suffices; no new domain Type needed.
- Verified 45 tests across formatter and both consumers, 100% all-four formatter/evaluation-component coverage, full test-source type-check, client build, diagnostics and diff formatting. Browser confirms padded short/hour values. No remaining Type cleanup or refactoring; changes uncommitted.

### Compact evaluation disclosures

- User refinement: right-align the duration column and remove the visible Elapsed duration prefix. Keep exact formatted values, unknown/unavailable reasons and the incomplete dash; observed exact-text Red before implementation.
- Duration refinement verified: six tests and 100% all-four component coverage, full test-source type-check, client build and diagnostics pass. Running-page value is duration-only and computed alignment is right. No Type/data changes or further cleanup needed; changes uncommitted.
- User requested separate aligned title/status/duration columns and full available page width. Use a grid summary with a disclosure indicator; stack status/duration beneath the title on narrow screens. Incomplete evaluations retain no elapsed-duration claim and display a dash in their duration column. Observed separate-field test Red before implementation; data/Types unchanged.
- Column refinement verified: six tests, 100% all-four component coverage, test-source type-check, client build, diagnostics and diff formatting pass. Browser confirms matching column positions across desktop rows, stacked fields at 320px with document width 305px, and Enter expansion/collapse. No new Type or remaining refactoring warranted; uncommitted.
- User refinement: place completion status and elapsed duration inline beside the title, with .75rem separation and natural wrapping on narrow screens. Native disclosure marker and behavior unchanged.
- User approved compact evaluation headers (title, completion status and elapsed duration) with expandable evidence, plus collapsed metric definitions and credit estimator. Native details/summary retains keyboard interaction and all existing content/controls. Missing completion means Not completed, not an inferred active lifecycle state.
- Observed two public-view tests fail before implementation. Existing dataset and duration formatter unchanged; no new Type warranted for this presentation-only change.
- Verified six tests with 100% component coverage, full test-source type-check, client build, diagnostics and diff formatting. Running page has 29 collapsed evaluation disclosures; expansion/collapse works via Enter on the summary. Metric definitions and estimator start collapsed. Corrected a nested closing-tag error during Green; no remaining refactoring or Type cleanup identified. Changes uncommitted.

### Top evaluated-work totals

- Subsequent user refinement: each summary total grows equally across the available page width, with a 14rem wrapping basis and border-box sizing. Keep narrow-screen wrapping and the existing grand-total accent.
- User requested separators specifically between Product, Meta and grand totals. Add palette-based vertical dividers on wide screens; stack totals with horizontal dividers at 50rem and below. Keep the grand-total divider accented and heading text unchanged.
- User approved moving Product and Meta subtotals and the grand total into a compact wrapping summary above the workflow table, with the subtle explanation directly underneath. Per-workflow elapsed totals stay in their rows; duplicate bottom totals removed. Existing calculation, deduplication and missing-duration semantics unchanged.
- Observed four top-summary tests fail before implementation. Reuse existing workflow groups and summedWorkflowElapsed; presentation-only rearrangement warrants no new domain Type.
- Verified: 23 component tests pass with 100% statement/branch/function/line coverage; full test-source type-check, client build, diagnostics and diff formatting pass. Running-page DOM/computed-style check confirms top placement, flex wrapping and no bottom total rows. Browser tab hidden; visible visual acceptance not claimed. No further refactoring needed; changes uncommitted.

### Subtle totals explanation

- User requested smaller, subtler totals explanatory text. Scoped style-only refinement: .75rem (12px), 1.5 line height and local muted gray-green #8e9b92. Contrast against page #171d19 is 5.92:1. Wording, totals and all interactions unchanged.

### Compact checkpoint label styling

- User requested much smaller checkpoint text, no gray background and no visible View checkpoint prefix. Approved workflow record; evaluation skipped for this small refinement.
- Preserve read-only document action and descriptive accessible name, native keyboard/focus behavior and sufficiently usable target. Reuse existing HTTP test boundary. Next: label Red, transparent small link-style Green, targeted tests/type/build and visible style check. No domain/API change.
- Completion: observed label-prefix Red, then 22 tests pass with 100% all-four component coverage. Full test-source type-check, client build, diagnostics and diff formatting pass. Both groups show only resumeLabel; accessible action unchanged.
- Styling: 12px (.75rem), normal-weight underlined text, transparent background/no border, palette secondary text, explicit focus-visible outline. Minimum target reduced from44px to24px for compact desktop labels (not the ticket-control convention); native button and wrapping retained. Browser computed styles confirm text/size/background/border/24px height; tab hidden, so no claim of visible visual or keyboard acceptance.
- User follow-up: checkpoint text now uses intentional local muted teal #89aaa5 rather than the neutral secondary role. Contrast against page background #171d19 is 6.82:1, above normal-text 4.5:1; size, background and action unchanged.
- Subsequent user refinement: use muted blue #8faac7 for the checkpoint text accent instead of teal. Contrast against #171d19 is 7.13:1; small transparent link-style presentation and action remain unchanged.
- Type review: existing resumeLabel is presentation text contrasting unchanged descriptive aria action; no representation/lifecycle/API change or new Type warranted. No test I/O or new mocks/interception. Evaluation intentionally skipped; previous evaluations unchanged. Active workflow remains canvas; refinement complete/uncommitted, phase idle. Suggested subject: Make workflow checkpoint labels compact and transparent.

### Product/meta subtotals and grand total

- Approved view-only group subtotal rows and grand total at table bottom. Count unique associated evaluations within each group and overall; shared cross-group evaluations can make subtotals exceed grand total. Keep summed-elapsed/not-effort and missing-duration semantics.
- Workflow and evaluation opted in before Red. Reuse summedEvaluationElapsed (already filters unique dataset records) and existing HTTP mocks; no new Type, boundary or storage. Next: public-view exact totals/deduplication Red, implementation, coverage/types/build/browser.
- Completion: three public-view tests failed before subtotal/footer implementation, then 34 TODO/duration tests pass. Component retains 100% all-four coverage; full test-source type-check, client build, diagnostics and diff formatting pass. Workflow Markdown generated twice identically.
- Type review: reuse WorkflowTodoList workflows/evaluationIds and unique validated dataset records; summedWorkflowElapsed gathers associations and delegates existing sum. Concrete shared test evaluation contributes once per group and once overall, contrasting repeated workflow associations; no new Type needed, no optional cleanup pending. Unknown/incomplete/unassociated semantics verified without test external I/O.
- Visible desktop: Product 3h 52m 4s, Meta 1h 43m 27s, Grand 5h 35m 31s, footer at table bottom. At 320px, table671px scrolls within271px region; document305 <= viewport320. Restored desktop. Totals will evolve with recorded completions.
- Global workflow remains active canvas exploration; this presentation slice complete/uncommitted, phase idle. Evaluation tracks acceptance not demonstrated usefulness; latency/active effort/overhead unknown. Suggested subject: Add product and meta elapsed subtotals and grand total.

### Summed evaluated elapsed time slice

- User approved per-workflow total beside completed count, labelled Summed elapsed (not effort). Sum completed evaluation durations only; missing timestamps remain explicit, never zero. Overlap/waiting caveat remains visible. Record workflow and evaluation before Red.
- Existing duration formatter and WorkEvaluation contract are prior art; reuse HTTP boundary mocks and pure duration tests. No domain/API/source-format change. Next: exact summation Red, reuse duration parsing/formatting, missing/invalid/reversed/incomplete tests, coverage/type/build/browser.
- Completion: exact 10m 56s UI sum failed before implementation; six aggregate cases failed for missing helper before implementation. 37 tests across duration, TODO and existing evaluation consumers pass at 100% all-four changed-module coverage. Full test-source type-check, client build, diagnostics and diff checks pass; generated workflow view twice identically.
- Refactor reuses private elapsed parsing and formatting for individual/aggregate displays, preserving Unknown/Unavailable distinctions and summing milliseconds before rounding. An initial misplaced method insertion caused a syntax failure; corrected before final passing checks. No hidden test I/O or new dependencies. Existing WorkEvaluation timestamp projection reused; no new domain Type.
- Type review: elapsed parsing returns numeric milliseconds or existing explicit display failure strings; distinguishing known zero from missing duration is required and tested. Example: zero-duration completed evaluation counts as known; null start does not. A richer named result could replace display strings if another consumer needs structured failure reasons; not justified for this display-only slice.
- Visible desktop verifies collapsed active history reads 13 completed / Summed elapsed: 2h 12m 33s. At 320px summary >=44px high, document width305 <= viewport320 and existing horizontal table scrolling preserved. Total is sum of intervals, not effort or deduplicated wall-clock; disclaimer explains waiting/overlap and excluded unknown/unavailable counts.
- Global workflow remains active canvas exploration; this TODO-view follow-up complete, uncommitted, phase idle. Evaluation records acceptance, not user benefit; latency/effort/overhead unknown. Suggested subject: Show summed evaluated elapsed time per workflow.

### Compact workflow navigation slice

- Approved: keep grouped table, remove repeated purpose column, top-align cells, collapse completed evaluations into count/disclosure with a vertical elapsed-time list and evidence navigation. Add View checkpoint using existing resume fields without switching workflows.
- User approved read-only document loading within this view because Browse is editable and does not jump to Markdown headings. Show checkpoint reference explicitly; no claim to jump to the heading.
- Evaluation opted in before Red. Existing HttpTestingController handles all API/file reads; no new boundary or test I/O. Presentation only; preserve shared/API/source meanings. Next: history disclosure Red/Green, then checkpoint lifecycle Red/Green, coverage/types/build/browser.
- Red observed missing details; implemented shared history template, array of completed summaries, count/disclosure, elapsed explanation/evidence link, four top-aligned columns with purpose communicated by group. 13 tests green; final old purpose-column assertion updated to grouped presentation and four headers. Next: verify all green, then checkpoint read-only loading/cancellation/errors tests before implementation. Phase cleared for continuation gate; no source authority change or workflow switch. Shared Types unchanged.
- Green checkpoint: 18 tests pass with 100% all-four component coverage; full test-source type-check passes and client build passed before final markup refinement. Four checkpoint Red tests failed for absent buttons before implementation. Read-only document load cancels prior pending subscription, handles errors visibly, resolves workflows/practices paths, unsubscribes on destroy; active workflow unchanged. Existing row tests now target workflow-name span rather than mixed name/button text. Errors follow BackendService's HttpErrorResponse message, not invented server-body extraction.
- Type review: existing WorkflowTodoList row reused for selected checkpoint; strings are read-only content/reference, Subscription models cancellable read ownership. Loading/error/content describe a small view lifecycle; cancellation prevents stale response overwrites. No demonstrated invalid state requiring a new named Type; preserve existing pattern. Completed item arrays are derived display strings, not new domain meaning. Null dataset guarded once and captured locally for type-safe synchronous mapping.
- Next: visible desktop/narrow/keyboard checks, final build/diagnostics, deterministic TODO generation and completion evaluation. Phase cleared at continuation gate; changes uncommitted.
- Completion (2026-10-10T00:11:33+02:00): 18 tests green at 100% all-four coverage, full client test-source type-check and final client build pass. Changed-file diagnostics and diff formatting clear. Generated TODO Markdown twice identically; JSON stays authoritative, shared/API contract unchanged.
- Visible acceptance: collapsed canvas workflow row 97px high, summary 13 completed, all four cells top-aligned. Keyboard Enter expands the vertical history and elapsed-time explanation/evidence link. View checkpoint loads actual canvas workflow Markdown read-only, includes reference and heading-jump limitation, no editable controls, active canvas workflow unchanged. At 320px, table scrolls (271px visible / 672px content), document width305 <= window320, history/checkpoint controls 44px high, checkpoint pre has no horizontal overflow. Restored desktop.
- Compliance: existing HTTP boundary mocks, explicit first-line Jest imports, no test external I/O, observed Red before history and checkpoint implementations, all-four coverage/type/build, lifecycle cancellation and Type review complete. No justified new Type or pending cleanup. No new meta practice warranted. Historical authority statements above remain history; no migration in this slice.
- Global workflow selection remains InteractiveCanvas Prototype; this approved TODO-view follow-up complete without switching work. Evaluation records observable acceptance, not demonstrated user benefit; decision latency/active effort/process overhead unknown. Uncommitted; phase idle. Suggested subject: Compact workflow history and expose read-only checkpoints.

**Next:** User review of the implemented read-only slice. API and UI were implemented through Red-Green-Refactor: 12 API tests and 12 client/navigation tests pass; the new handler and component each have 100% coverage on all four metrics. Shared/client builds, the scoped server TypeScript check and editor diagnostics pass. No Type cleanup remains.

Browser verification: the existing client server still served old routes, so the production build was checked on an isolated local server. The hidden browser tab initially blocked normal clicks and visible event updates; making the test tab visible resolved this without application changes. Verified toolbar navigation from Problem Inquiry to the five-row TODO list, unchanged legacy TODO link, active status, and opening the DevEnv Export document with its checkpoint reference. At 320, 768 and 1440px, the table stays within its scroll container and document text wraps without document overflow. These checks are not screen-reader certification.

### Agreed representation

- Keep the Workflow TODO List Markdown authoritative; derive JSON rather than maintaining a duplicate list.
- The UI consumes that JSON. Do not display the unrelated commit-process KnowledgeStatements example as workflows.
- Approved shared Type name: `WorkflowTodoList`, containing `workflows`.
- Each workflow has `name`, `primaryWorkPurpose`, `status`, `resumeLabel`, `resumePath`, and `relatedConcern`. The view displays the name, purpose, status, and related concern; resume references remain in the source/API but are not shown in the view. Status remains descriptive text, not a newly agreed lifecycle Type.
- Concrete example: `TODO View (DevEnv system layer)`, `Pending`, `Starting checkpoint`, `./todo-view-workflow.md#checkpoint`, `Not assigned`.
- The user approved a separate `Workflow TODO` toolbar link and a read-only table/document view, retaining the existing `TODO.md` link.
- Resume buttons load the complete workflow Markdown document and display the checkpoint reference. They do not jump to a heading, edit, or switch workflows.
- JSON is derived live by `GET /workflow-todo`; no generated JSON snapshot is maintained.

### Remaining decisions

- No existing concern was identified as directly covering this workflow view; it remains unassigned rather than attributing it to glossary scope SC-027. A new register entry remains a separate decision.

Type review: `WorkflowTodoList` is justified as the shared API representation of the existing list. No additional status or lifecycle Type is adopted. The row Type name remains to be agreed if a separately named Type is needed.

The row structure is inline in `WorkflowTodoList`; no additional name was needed for this slice. Glossary Refinement is paused with its existing checkpoint preserved.

## Follow-up checkpoint: work-purpose API and view compatibility

**Status:** Implementation and verification complete; user review remains separate.

The workflow register gained a `Primary work purpose` column, while the `/workflow-todo` parser still required the previous four-column table. This caused the reported missing-header error. The Markdown register remains authoritative; the endpoint derives its response from it, and no global TODO JSON source was added.

The parser and shared API contract now accept and validate the five-column schema, and the API response carries `primaryWorkPurpose`. The workflow view displays that field in a labelled table column. Red was observed against focused direct-handler and client tests before their respective changes. The direct-handler suite passes all seven tests and the client component suite all twelve; each changed production module has 100% statement, branch, function, and line coverage. The server scoped TypeScript check and shared and client builds pass. `git diff --check` passes.

The existing API Supertest suite was not run because it uses localhost/socket activity that is outside the current test boundary policy. Its fixture was updated to the five-column format; direct handler tests exercise the parser and current Markdown without network activity.

`WorkflowWorkPurpose` is a supporting API Type for the two existing labels (`Product work` and `Meta work`). No conflicting existing Type was found; the name accurately distinguishes the value from workflow status and describes its purpose in the API contract. This does not establish a new Glossary Term or a broader domain Type beyond the two registered labels. No global list authority change is proposed.

**Next:** User review of the updated read-only view and its purpose column.

## Follow-up checkpoint: JSON authority migration

**Status:** Implementation and verification complete; user review and commit approval remain separate.

The user approved making Typed JSON authoritative for the global Workflow TODO list. The [workflow-todo-list.json](./workflow-todo-list.json) now contains the 12 workflow records and the prior register's introductory, classification, maintenance, switching, and status guidance. [workflow-todo-list.md](./workflow-todo-list.md) is regenerated as the human-readable view. The `/workflow-todo` handler now reads and runtime-validates the JSON rather than parsing Markdown. The active selection is this workflow; DevEnv Value Evaluation is paused with its next diagram-editor slice preserved in its detailed checkpoint.

Added an explicit `WorkflowTodoList` interface/runtime validator, a deterministic renderer and generator command (`npm run generate:workflow-todo:markdown`), and focused direct-handler/renderer tests. All 30 focused server tests pass; the handler, validator, and exporter each have 100% statement, branch, function, and line coverage. The server TypeScript check and shared/client builds pass; 12 client tests pass. Regenerating twice produced byte-identical Markdown (SHA-256 `FE548BFE247EE56431B883B542DBAD056E1D2F7B3A0A65C39745410F70ADFC74`), 13 local links resolve, and `git diff --check` passes. The prior API Supertest tests were replaced with direct handler tests that do not start a network listener; the repository-backed test reads the JSON source (read-only).

Runtime follow-up: `tsx watch` could not resolve the handler's runtime `@shared` import because the repository alias points to `dist/shared` and is not available to this Node runtime. The handler now imports the validator from the shared source by a relative path. The dev server started successfully and `GET /workflow-todo` returned the validated JSON list.

**Architecture follow-up:** The server currently imports the shared validator directly from the shared source file. This is a compatibility workaround, not the desired package boundary. Improve server runtime module resolution so it can consume the supported `@shared` package entry point consistently in development and production, then remove the direct source-file import. Keep this separate from the JSON-authority migration.

**Follow-up:** The user requested removing `Resume reference` from the workflow view. The UI table now contains workflow, purpose, status, and related concern only; document-opening UI and its loading state were removed. Resume paths remain in the authoritative JSON and API for checkpoint navigation data, but are not presented by this view.

**Next:** User review of the reduced workflow view.

No global list authority remains in Markdown or API parsing. `WorkflowTodoList` is the already-approved shared Type name. `WorkflowWorkPurpose` has two constrained values; the record shapes remain inline rather than adding a separate row Type.

## Follow-up checkpoint: separate end-user and meta work

**Status:** Implementation and verification complete; user review remains separate.

The user requested visually separating DevEnv meta workflows from end-user tools/capabilities, with meta work last. The view now renders two labelled sections in that order. It filters the existing workflow array only for presentation; source order, JSON records, and shared/API Types are unchanged. Sections are both visible rather than using tabs so users can compare the groups at once.

The focused client suite passes (9 tests), and the component has 100% statement, branch, function, and line coverage. The client build and `git diff --check` pass. Browser visual verification was not performed.

**Next:** User review of the grouped presentation.

## Follow-up checkpoint: separate evaluation details

**Status:** Implementation and verification complete; user review remains separate.

The user requested moving full evaluation details into a separate page/view and showing a metrics summary on the workflow page. The summary now presents each metric's count of recorded versus unknown evaluations and links to `/workflow-evaluations`. That route displays metric definitions and complete per-evaluation context and measures from the existing authoritative JSON. The source data and shared/API Types are unchanged.

Focused workflow/evaluation/route tests pass (20 total), with 100% statement, branch, function, and line coverage for both changed production components. The client source type-check and client build pass. Browser visual verification was not performed.

**Next:** User review of the split presentation.

### Follow-up: direct evaluation navigation

The user asked whether the evaluation route was available in the menu and approved adding it. The toolbar now links directly to `/workflow-evaluations` beside Workflow TODO; the existing in-page link remains. The toolbar and route suites pass (12 tests), toolbar component coverage is 100% for statements, branches, functions, and lines, and the client build passes.

### Follow-up: completed evaluation duration

The evaluations view derives elapsed wall-clock duration for completed records from their existing `startedAt` and `completedAt` values. Incomplete records omit the duration; completed records with missing or invalid timestamps show an explicit unavailable/unknown value. This does not alter the JSON schema or imply active human effort. The display and error cases are covered through the component's public view.

The combined focused suites pass (25 tests); route, toolbar, workflow, and evaluations components each have 100% statement, branch, function, and line coverage. The client development TypeScript check and client build pass. Browser visual verification was not performed.

**Next:** User review of the combined workflow/evaluation presentation. Changes remain uncommitted.

### Follow-up: completed durations on workflow view

The user clarified that completed-item durations should appear on the workflow items themselves, not in a separate list beneath the metric summary. The view now displays each associated completed evaluation title and derived elapsed wall-clock duration in a new column on the corresponding workflow row, using the same formatter as the evaluation detail page. The two current presentation mappings associate Diagram selection and movement with Minimal Typed Diagram Editor and Show current evaluation metrics on the Workflow TODO view with TODO View (DevEnv system layer). Unmatched workflows show no associated evaluated item; incomplete evaluations are not associated. The source data and Types are unchanged.

The focused workflow/evaluation suites pass (14 tests); the workflow component, evaluation component, and shared duration formatter have 100% statement, branch, function, and line coverage. The client development TypeScript check, client build, and `git diff --check` pass. No browser visual verification was performed.

**Next:** User review of the inline workflow-row presentation. Changes remain uncommitted, separate from commit `7bc3cc2`.

### Follow-up: align grouped workflow columns

The user requested aligning the Product and Meta table columns. The two separate tables were replaced with one semantic table containing separate Product and Meta row groups. This makes both groups share exactly one set of columns rather than depending on independently sized tables. The group order, labels, row content, and narrow-screen horizontal scrolling are preserved.

The focused workflow component suite passes (10 tests) with 100% statement, branch, function, and line coverage. The client development TypeScript check and client build pass.

**Next:** User review of the shared-table presentation. This presentation-only follow-up remains uncommitted.

### Follow-up: use full page width

The user requested that the workflow table stretch across the page. Removed the Workflow TODO content area's 76rem maximum width, set it to the available width with box-sizing applied, and retained responsive side padding. The table remains 100% width of this expanded content area; narrow screens keep the existing horizontal scroll behavior.

The focused workflow component suite passes (10 tests), the component has 100% statement, branch, function, and line coverage, and the client development TypeScript check and build pass. Browser visual verification was not performed.

**Next:** User review of the full-width workflow table. Changes remain uncommitted.
